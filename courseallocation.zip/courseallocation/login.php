<!doctype html>
	<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="Asqure Techz Solutions">
		<meta name="author" content="Abubakar Ahmad Yusuf">
		<link rel="icon" type="image/jpg" sizes="100x100" href="images/fav.jpg">
		<!--CSS resources-->
		<link href="resources/mato/tools/bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
		<link href="resources/css/animate.css" type="text/css" rel="stylesheet" />
		<link href="resources/css/styles.css" type="text/css" rel="stylesheet" />
		<script type="text/javascript" language="javascript" src="resources/mato/tools/JQuery/jquery.min.js"></script>
		<script  type="text/javascript" language="javascript" src="resources/mato/lib/JMatt/global.js"></script>
		<script  type="text/javascript" language="javascript" src="resources/mato/lib/JMatt/modal.js"></script>

	</head>
	<body>
		<nav class="navbar navbar-default">
			<div class="container-fluid">
				
			</div>
		</nav>
		<div class="container">
			<div class="row">
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-body">
							<form class="form-login" method="post" id="login-form">
						<h3 class=""><img alt="" src="resources/img/polylogo.jpg" width="50" height="50"> CS Dept - Course Allocation App.</h3><hr />
						<div id="error">
						</div>
						<div class="form-group">
							<input type="email" class="form-control" placeholder="Email address" name="user_email" id="user_email" />
							<span id="check-e"></span>
						</div>
						<div class="form-group">
							<input type="password" class="form-control" placeholder="Password" name="password" id="password" />
						</div>

						<hr />
						<div class="form-group">
							<button type="submit" class="btn btn-success" name="login_button" id="login_button">
								<span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In
							</button> 
						</div> 
					</form>
					<center><small>Copyright &copy; All rights reserved CS-Dept FPTB</small></center>
						</div>
					</div>
					
				</div>
				<div class="col-md-3"></div>
			</div>
		</div>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
		<script  type="text/javascript" language="javascript" src="resources/js/js.js"></script>
		<script  type="text/javascript" language="javascript" src="resources/js/l.js"></script>
		<script  type="text/javascript" language="javascript" src="resources/js/c.js"></script>
		<script type="text/javascript" src="script/validation.min.js"></script>
		<script type="text/javascript" src="script/login.js"></script>
	</body>
	</html>