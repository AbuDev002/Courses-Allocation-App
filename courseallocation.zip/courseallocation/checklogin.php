<?php
session_start();
include_once("db_connect.php");
if(isset($_POST['login_button'])) {
	$user_email = trim($_POST['user_email']);
	$user_password = trim($_POST['password']);
	$pass_hash = md5($user_password);
	
	$sql = "SELECT * FROM users WHERE email='$user_email' AND pass='$pass_hash'";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	$row = mysqli_fetch_array($resultset);	
		//$row['pass']==$user_password
	if(mysqli_num_rows($resultset) > 0){			
		echo "ok";
		$_SESSION['user_session'] = $row['uid'];
	} else {				
		echo "email or password is incorrect."; // wrong details 
	}		
}
?>