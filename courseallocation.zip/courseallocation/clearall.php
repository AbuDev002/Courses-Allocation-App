<?php
		include_once('db_connect.php');
		$flush = mysqli_query($conn,"UPDATE courses SET lecturer_in_charge =''");
		if($flush){
			echo"<script>alert('Record Cleared Successfully')</script>";
			header('location:index.php');
		}
?>
					