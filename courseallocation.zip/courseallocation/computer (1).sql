-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2021 at 01:26 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `computer`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_code` char(20) NOT NULL,
  `course_title` char(255) NOT NULL,
  `course_unit` int(1) NOT NULL,
  `level` char(10) NOT NULL,
  `course_scope` varchar(1000) NOT NULL,
  `lecturer_in_charge` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_code`, `course_title`, `course_unit`, `level`, `course_scope`, `lecturer_in_charge`) VALUES
('COM 101', 'INTRODUCTION TO COMPUTERS', 3, 'NDI', 'Computer and Information Systems Manager', ''),
('COM 112', 'INTRODUCTION TO DIGITAL ELECTRONICS', 3, 'NDI', 'Digital Electronic', ''),
('COM 113', 'INTRODUCTION TO PROGRAMMING', 3, 'NDI', 'Programming', ''),
('COM 121', 'SCIENTIFIC PROGRAMMING LANGUAGE USING OO JAVA', 4, 'NDI', 'Programming, Software Developer', ''),
('COM 122', 'INTRODUCTION TO INTERNET', 3, 'NDI', 'Computer Network Architect', ''),
('COM 123', 'COMPUTER APPLICATION PACKAGES I', 4, 'NDI', 'Word Processing', ''),
('COM 124', 'DATA STRUCTURE AND ALGORITHM', 3, 'NDI', 'Data Structure, Data Architect', ''),
('COM 125', 'INTRODUCTION TO SYSTEM ANALYSIS', 3, 'NDI', 'Systems Analyst, Computer and Information Research Scientists', ''),
('COM 126', 'PC UPGRADE AND MAINTENANCE', 4, 'NDI', 'Computer Engineering, Hardware Engineers', ''),
('COM 211', 'COMPUTER PROGRAMMING USING OO BASIC', 3, 'NDII', 'Programming, Software Developer', ''),
('COM 212', 'INTRODUCTION TO SYSTEM PROGRAMMING', 3, 'NDII', 'Programming', ''),
('COM 213', 'COMMERCIAL PROGRAMMING USING OO COBOL', 3, 'NDII', 'Programming', ''),
('COM 214', 'FILE ORGANIZATION AND MANAGEMENT', 3, 'NDII', 'IT Project Manager, Project Manager', ''),
('COM 215', 'COMPUTER PACKAGES II', 4, 'NDII', 'Word Processing', ''),
('COM 216', 'COMPUTER SYSTEM TROUBLESHOOTING I', 3, 'NDII', 'Hardware Engineers, Computer Engineering', ''),
('COM 221', 'COMPUTER PROGRAMMING USING OO FORTRAN', 4, 'NDII', 'Programming', ''),
('COM 222', 'SEMINAR ON COMPUTER AND SOCIETY', 2, 'NDII', 'IT Project Manager', ''),
('COM 223', 'BASIC HARDWARE MAINTAINANCE', 3, 'NDII', 'Computer Engineering, Hardware Engineers', ''),
('COM 224', 'MANAGEMENT INFORMATION SYSTEM', 3, 'NDII', 'Information Security Analyst', ''),
('COM 225', 'WEB TECHNOLOGY', 4, 'NDII', 'Web Technology', ''),
('COM 226', 'COMPUTER SYSTEM TROUBLESHOOTING II', 3, 'NDII', 'Computer Engineering', ''),
('COM 229', 'PROJECT', 3, 'NDII', 'Project Research', ''),
('COM 311', 'OPERATING SYSTEM I', 3, 'HNDI', 'Software Engineering', ''),
('COM 312', 'DATABASE DESIGN I', 3, 'HNDI', 'Database Administrator, Database Developer', ''),
('COM 313', 'COMPUTER PROGRAMMING USING C++', 3, 'HNDI', 'Programming', ''),
('COM 314', 'COMPUTER ARCHITECTURE', 2, 'HNDI', 'Data Architect', ''),
('COM 321', 'OPERATING SYSTEM II', 3, 'HNDI', '', ''),
('COM 322', 'DATABASE DESIGN II', 3, 'HNDI', 'Database Administrator', ''),
('COM 323', 'ASSEMBLY LANGAUGE', 3, 'HNDI', 'Programming', ''),
('COM 324', 'INTRODUCTION TO SOFTWARE ENGINEERING', 3, 'HNDI', 'Software Engineering', ''),
('COM 326', 'INTRODUCTION TO HUMAN - COMPUTER INTERFACE (HCI)', 2, 'HNDI', 'Multimedia', ''),
('COM 412', 'COMPUTER PROGRAMMING USING OO PASCAL', 3, 'HNDII', 'Programming', ''),
('COM 413', 'PROJECT MANAGEMENT', 3, 'HNDII', 'IT Project Manager', ''),
('COM 414', 'COMPILER CONSTRUCTION', 3, 'HNDII', 'Applications Developer', ''),
('COM 415', 'DATA COMMUNICATION AND NETWORKS', 3, 'HNDII', 'Computer Network Architect', ''),
('COM 416', 'MULTIMEDIA', 3, 'HNDII', 'Multimedia', ''),
('COM 422', 'COMPUTER GRAPHICS AND ANIMATION', 3, 'HNDII', 'Multimedia', ''),
('COM 423', 'INTRODUCTION TO ARTIFICIAL INTELLIGENCE AND EXPERT SYSTEMS', 3, 'HNDII', 'AI Technology', ''),
('COM 424', 'PROFESSIONAL PRACTICE IN IT', 3, 'HNDII', 'Artificial Intelligence', ''),
('COM 425', 'SEMINAR ON CURRENT TOPICS IN COMPUTING', 2, 'HNDII', 'Seminar Presentation', ''),
('COM 426', 'SMALL BUSINESS STARTUP', 2, 'HNDII', 'Business Startup', ''),
('COM 429', 'PROJECT', 6, 'HNDII', 'Project Research', ''),
('EED 126', 'INTRODUCTION TO ENTREPRENEURSHIP', 2, 'NDI', 'Business Intelligence Analyst, Business Management', ''),
('EED 216', 'PRACTICE OF ENTREPRENEURSHIP', 2, 'NDII', 'Business Management', ''),
('EED 323', 'ENTREPRENEURSHIP DEVELOPMENT I', 2, 'HNDI', '', ''),
('EED 413', 'ENTREPRENEURSHIP DEVELOPMENT II', 2, 'HNDII', 'Enterpreneurship Development', ''),
('GNS 103', 'USE OF LIBRARY', 2, 'NDI', 'Use of Library', ''),
('GNS 127', 'CITIZENSHIP EDUCATION I', 2, 'NDI', 'Citizenshi Education', ''),
('GNS 128', 'CITIZENSHIP EDUCATION II', 2, 'NDI', 'Citizinship Education', ''),
('MTH 112', 'FUNCTION AND GEOMETRY', 2, 'NDI', 'Sample Survey, Statistical Inference', ''),
('MTH 113', 'LOGIC & LINEAR ALGEBRA', 2, 'NDI', 'Logic and Linear Algebra', ''),
('OTM 101', 'TECHNICAL ENGLISH I', 2, 'NDI', 'Function and Geometry', ''),
('OTM 217', 'TECHNICAL ENGLISH II', 2, 'NDII', 'Technical English', ''),
('OTM 315', 'BUSINESS COMMUNICATION I', 2, 'HNDI', 'Business Communication', ''),
('OTM 412', 'BUSINESS COMMUNICATION II', 3, 'HNDI', '', ''),
('STA 112', 'ELEMENTARY PROB. THEORY', 3, 'NDI', 'Probability Theory', ''),
('STA 114', 'DESCRIPTIVE STATISTICS I', 3, 'NDI', 'Descriptive Statistics', ''),
('STA 226', 'SMALL BUSINESS MANAGEMENT I', 2, 'NDII', 'Small Business Management', ''),
('STA 314', 'OPERATIONAL RESEARCH I', 3, 'HNDI', '', ''),
('STA 321', 'STATISTICAL THEORY II', 2, 'HNDI', '', ''),
('STA 411', 'OPERATION RESEARCH II', 3, 'HNDII', 'Operational Research', ''),
('STA3 11', 'STATISTICS THEORY I', 2, 'HNDI', '', ''),
('SWE 200', 'SIWES', 4, 'NDII', 'Students Industrial Work Experience', '');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(50) NOT NULL,
  `title` char(10) NOT NULL,
  `first_name` char(255) NOT NULL,
  `last_name` char(255) NOT NULL,
  `initial` char(5) NOT NULL,
  `rank` char(20) NOT NULL,
  `specialization` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Lecturer''s entity';

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `title`, `first_name`, `last_name`, `initial`, `rank`, `specialization`) VALUES
(1634816563, 'Mal.', 'Salisu', 'Abdullahi', 'B.Tec', 'Snr Lect.', 'Word Processing, Project Manager'),
(1634816913, 'Mal.', 'Yakubu', 'Danjuma', 'Bsc.', 'Lect. II', 'Programming'),
(1634816959, 'Mal.', 'Muhammad', 'Kuliya', 'B.Tec', 'Snr. Lect.', 'Cyber Security, Database Administrator'),
(1634817010, 'Mr.', 'Ikenna', 'Chukuwuka Onourah', 'HND C', 'Higher Instructor', 'Programming, Applications Developer'),
(1634817062, 'Mal.', 'Sanusi', 'Abdulhamid', 'Bsc C', 'Lect III', 'Word Processing'),
(1634817165, 'Mal.', 'Abdulrahman', 'Abdulkarim', 'B.Tec', 'Lect. II', 'Systems Analyst, Computer and Information Research Scientists'),
(1634817178, 'Mal.', 'Abubakar', 'Ahmad Yusuf', 'HND C', 'Technologist II', 'Programming, Web Technology, Database Administrator'),
(1634817578, 'Mal.', 'Ishaq', 'Muhammad', 'B.Tec', 'Lect. III', 'Database Administrator, Computer and Information Systems Manager,Word Processing'),
(1634817716, 'Mrs.', 'Aishatu', 'Yahaya', 'Bsc.', 'Asst. Lect', 'Word Processing'),
(1634817846, 'Mal.', 'Abdullahi', 'Muhammad Nuhu', 'Bsc.', 'Asst. Lect', 'Word Processing'),
(1634817937, 'Mal.', 'Abubakar', 'Sulaiman Hamza', 'HND C', 'Principal Tech.', 'Internet of things, Embeded systems, Database Administrator, Multimedia'),
(1634818144, 'Mal.', 'Ahmadu', 'Maidorawa', 'B.TEC', 'Cheif Lect', 'Computer Network Architect,Software Engineering'),
(1634818205, 'Mal.', 'Lele', 'Muhammad', 'B.TEC', 'Lect. II', 'Artificial Intelligence, Programming'),
(1634818561, 'Mal.', 'Abubakar', 'Ahmed Sambo', 'Bsc.', 'Asst. Lect', 'Web Technology'),
(1634820025, 'Mal.', 'Abdulkadir', 'M. Turaki', 'Bsc.', 'Lect. II', 'Programming'),
(1634820065, 'Mal.', 'Zakari', 'Idris Matinja', 'B.Tec', 'Cheif Lec', 'Web Technology, Programming, Database Administrator'),
(1634820427, 'Mrs.', 'Aishatu', 'Adam Yahaya', 'HND C', 'Higher Instructor', 'Word Processing'),
(1634820640, 'Mrs.', 'Zainab', 'Aliyu', 'Bsc C', 'Lect I', 'Word Processing, Database Developer'),
(1634820803, 'Mrs.', 'Atika', 'Ahmad Jibrin', 'Bsc.', 'Lect. II', 'Business Management, Word Processing'),
(1634821342, 'Mal.', 'Muhammad', 'Aliyu', 'B.Tec', 'Lect I', 'Computer Network Architect, Data Architect'),
(1634821362, 'Mal.', 'Abubakar', 'Muhammad', 'Msc C', 'Snr. Lect', 'Artificial Intelligence, Database Administrator, Database Developer'),
(1634821406, 'Mal.', 'Khalil', 'Sani Ibrahim', 'Bsc.', 'Asst. Lect', 'Word Processing'),
(1634821858, 'Mrss.', 'Ify', 'Madu', 'B.TEC', 'Chief Lect', 'Project Manager, IT Project Manager, Systems Analyst'),
(1634822128, 'Mal.', 'Abdulrazak', 'Bello Ahmed', 'B.Tec', 'Asst. Lect', 'Computer and Information Systems Manager'),
(1634822606, 'Mal.', 'Lawan', 'Garba', 'B.Tec', 'Asst. Lect', 'Word Processing'),
(1634822665, 'Mal.', 'Yamusa', 'Idris', 'B.TEC', 'Lect. II', 'Word Processing'),
(1634822675, 'Mal.', 'Idris', 'Yau Idris', 'Bsc.', 'Lect. III', 'Word Processing'),
(1634822832, 'Mal.', 'Suleiman', 'Abdulrasheed Sadiq', 'HND C', 'Technologist II', 'Hardware Engineers'),
(1634822947, 'Dr.', 'Musa', 'Ilya Adamu', 'B.Tec', 'Lect. I', 'Programming, Information Technology Auditor'),
(1634823061, 'Mal.', 'Usman', 'Sani', 'B.Sc.', 'Chief Lect', 'Hardware Engineers'),
(1634823219, 'Mal.', 'Suberu', 'Yusuf', 'B.Tec', 'Lect. III', 'Word Processing'),
(1634823902, 'Mal.', 'Hassan', 'Abubakar', 'HND C', 'Snr. Tech', 'Database Developer, Database Administrator, Data Structure'),
(1634824133, 'Mr.', 'Adonu', 'Sunday', 'B.Eng', 'Snr Lect', 'Embeded systems, Hardware Engineers'),
(1634824147, 'Mal.', 'Zaharaddeen', 'Bala', 'HND (', 'Technologist I', 'Data Architect, Data Structure, Programming, Database Administrator'),
(1634824520, 'Mrs.', 'Benesemeni', 'Zakka', 'B.Tec', 'Lect. I', 'Word Processing'),
(1634825080, 'Mrs.', 'Ammatullah', 'Yahaya Aliyu', 'B.Tec', 'Lect. II', 'Database Developer, Database Administrator'),
(1634825547, 'Haj.', 'Fatima', 'Ahmad Abubakar', 'B.Tec', 'Lect. II', 'Digital Electronic, Computer Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `profile_photo` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `user`, `pass`, `email`, `profile_photo`) VALUES
(1, 'test', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin@fptb.cs', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
