<?php
/*******************This part is to set up the database and the tables****************/
$_connection = mysqli_connect(config::$db_host,config::$db_user,config::$db_password);
$db_name = str_replace(array(' ',','),'_',config::$department);
	mysqli_select_db($_connection,config::$department);
if($_connection){
	$_create_db = mysqli_query($_connection,"CREATE DATABASE IF NOT EXISTS ".$db_name." DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci");
		
	if($_create_db){
		
	mysqli_select_db($_connection,config::$department);
	
	$_create_courses_table = mysqli_query($_connection,"CREATE TABLE `courses`
						   (`course_code` char(20) NOT NULL,
						  `course_title` char(255) NOT NULL,
						  `course_unit` int(1) NOT NULL,
						  `level` char(10) NOT NULL,
						  `course_scope` varchar(1000) NOT NULL,
						  `lecturer_in_charge` char(255) NOT NULL)
						ENGINE=InnoDB DEFAULT CHARSET=latin1;");
						
	
	$_add_course_primary_key = mysqli_query($_connection,"ALTER TABLE `courses` ADD PRIMARY KEY (`course_code`)");
		

	
	$_create_lecturer_table = mysqli_query($_connection,"CREATE TABLE `lecturer` 
							(`id` int(50) NOT NULL,
							  `title` char(10) NOT NULL,
							  `first_name` char(255) NOT NULL,
							  `last_name` char(255) NOT NULL,
							  `initial` char(5) NOT NULL,
							  `rank` char(20) NOT NULL,
							  `specialization` char(255) NOT NULL)
							  ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Lecturer''s entity'");
	
	$_add_lecturer_primary_key = mysqli_query($_connection,"ALTER TABLE `lecturer` ADD PRIMARY KEY (`id`)");
	
	if(mysqli_num_rows(mysqli_query($_connection,"SELECT id FROM lecturer")) == 0){//if no lecturer record exist yet
//Add all lecturers initially
$lecturers = array(
				array('title' => 'Mal.','first_name' => 'Usman', 'last_name' => 'Sani', 'initial' => 'B.Sc. Physics (1987), PGD Comp Sci (2000), M.Sc. Comp Sci (2006) CPN', 'rank' => 'Chief Lect', 'specialization' => 'Hardware Engineers'),
				array('title' => 'Mrss.','first_name' => 'Ify', 'last_name' => 'Madu', 'initial' => 'B.TECH, Math/Comp (1991) M.Sc. Comp Sci (HONS) (2000) NCS, CPN', 'rank' => 'Chief Lect','specialization' => 'Project Manager, IT Project Manager, Systems Analyst'),
				array('title' => 'Mal.','first_name' => 'Ahmadu', 'last_name' => 'Maidorawa', 'initial' => 'B.TECH, Math/Comp (1991) M.Sc. Comp Sci (HONS) (2000) NCS, CPN', 'rank' => 'Cheif Lect', 'specialization' => 'Computer Network Architect,Software Engineering'),
				array('title' => 'Mal.','first_name' => 'Abubakar', 'last_name' => 'Muhammad', 'initial' => 'Msc Comp Sci (2018) NCS', 'rank' => 'Snr. Lect', 'specialization' => 'Artificial Intelligence, Database Administrator, Database Developer'),
				array('title' => 'Mal.','first_name' => 'Hassan', 'last_name' => 'Abubakar', 'initial' => 'HND Comp Sci (2006),Msc Info Tech (2017),NCS,CPN', 'rank' => 'Snr. Tech', 'specialization' => 'Database Developer, Database Administrator, Data Structure'),
				array('title' => 'Mal.','first_name' => 'Abubakar', 'last_name' => 'Sulaiman Hamza', 'initial' => 'HND Comp Sci (2008), Msc (2021)', 'rank' => 'Principal Tech.', 'specialization' => 'Internet of things, Embeded systems, Database Administrator, Multimedia'),
				array('title' => 'Mr.','first_name' => 'Adonu', 'last_name' => 'Sunday', 'initial' => 'B.Engr Comp Engr., Msc Electronic and Comm (2015)', 'rank' => 'Snr Lect', 'specialization' => 'Embeded systems, Hardware Engineers'),
				array('title' => 'Mal.','first_name' => 'Salisu', 'last_name' => 'Abdullahi', 'initial' => 'B.Tech Comp Sci (2004), Msc (2016), NCS', 'rank' => 'Snr Lect.', 'specialization' => 'Word Processing, Project Manager'),
				array('title' => 'Mal.','first_name' => 'Muhammad', 'last_name' => 'Kuliya', 'initial' => 'B.Tech Comp Sci (2003), PGDE (2010) Msc (2020), NCS, CPN', 'rank' => 'Snr. Lect.', 'specialization' => 'Cyber Security, Database Administrator'),
				array('title' => 'Dr.','first_name' => 'Musa', 'last_name' => 'Ilya Adamu', 'initial' => 'B.Tech Comp Sci (2009), Msc Comp Sci (2015), Phd (2021), CPN', 'rank' => 'Lect. I', 'specialization' => 'Programming, Information Technology Auditor'),
				array('title' => 'Mal.','first_name' => 'Muhammad', 'last_name' => 'Aliyu', 'initial' => 'B.Tech Comp Sci (2009), Msc Comp Sci (2015), NCS, CPN', 'rank' => 'Lect I', 'specialization' => 'Computer Network Architect, Data Architect'),
				array('title' => 'Mrs.','first_name' => 'Benesemeni', 'last_name' => 'Zakka', 'initial' => 'B.Tech Comp Sci. (2008), PGDE (2012), Msc (2020), NCS', 'rank' => 'Lect. I', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Zakari', 'last_name' => 'Idris Matinja', 'initial' => 'B.Tech Comp Sci (2008), Msc (2020)', 'rank' => 'Cheif Lec', 'specialization' => 'Web Technology, Programming, Database Administrator'),
				array('title' => 'Mrs.','first_name' => 'Zainab', 'last_name' => 'Aliyu', 'initial' => 'Bsc Comp Sci. (2009), PGDE (2014), Msc (2020), CPN', 'rank' => 'Lect I', 'specialization' => 'Word Processing, Database Developer'),
				array('title' => 'Mal.','first_name' => 'Lele', 'last_name' => 'Muhammad', 'initial' => 'B.TECH Comp Sci (2010)', 'rank' => 'Lect. II', 'specialization' => 'Artificial Intelligence, Programming'),
				array('title' => 'Mal.','first_name' => 'Yamusa', 'last_name' => 'Idris', 'initial' => 'B.TECH Comp Sci (2010)', 'rank' => 'Lect. II', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Yakubu', 'last_name' => 'Danjuma', 'initial' => 'Bsc. Comp Sci (2010)', 'rank' => 'Lect. II', 'specialization' => 'Programming'),
				array('title' => 'Mal.','first_name' => 'Abdulkadir', 'last_name' => 'M. Turaki', 'initial' => 'Bsc. Comp Sci (2012)', 'rank' => 'Lect. II', 'specialization' => 'Programming'),
				array('title' => 'Mrs.','first_name' => 'Ammatullah', 'last_name' => 'Yahaya Aliyu', 'initial' => 'B.Tech Comp Sci (2009), PGDE (2010), Msc (2018)', 'rank' => 'Lect. II', 'specialization' => 'Database Developer, Database Administrator'),
				array('title' => 'Mal.','first_name' => 'Abdulrahman', 'last_name' => 'Abdulkarim', 'initial' => 'B.Tech Comp Sci (2012)', 'rank' => 'Lect. II', 'specialization' => 'Systems Analyst, Computer and Information Research Scientists'),
				array('title' => 'Mal.','first_name' => 'Ishaq', 'last_name' => 'Muhammad', 'initial' => 'B.Tech Comp Sci (2012)', 'rank' => 'Lect. III', 'specialization' => 'Database Administrator, Computer and Information Systems Manager,Word Processing'),
				array('title' => 'Haj.','first_name' => 'Fatima', 'last_name' => 'Ahmad Abubakar', 'initial' => 'B.Tech Comp Sci (2005), Msc (2021)', 'rank' => 'Lect. II', 'specialization' => 'Digital Electronic, Computer Engineering'),
				array('title' => 'Mrs.','first_name' => 'Atika', 'last_name' => 'Ahmad Jibrin', 'initial' => 'Bsc. Comp Sci (2012)', 'rank' => 'Lect. II', 'specialization' => 'Business Management, Word Processing'),
				array('title' => 'Mal.','first_name' => 'Suberu', 'last_name' => 'Yusuf', 'initial' => 'B.Tech Comp Sci (2010)', 'rank' => 'Lect. III', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Sanusi', 'last_name' => 'Abdulhamid', 'initial' => 'Bsc Comp Sci (2014)', 'rank' => 'Lect III', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Zaharaddeen', 'last_name' => 'Bala', 'initial' => 'HND (2016) PGD (2017)', 'rank' => 'Technologist I', 'specialization' => 'Data Architect, Data Structure, Programming, Database Administrator'),
				array('title' => 'Mal.','first_name' => 'Idris', 'last_name' => 'Yau Idris', 'initial' => 'Bsc. Comp Sci (2011)', 'rank' => 'Lect. III', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Abdulrazak', 'last_name' => 'Bello Ahmed', 'initial' => 'B.Tech Maths/Comp Sci (2013)', 'rank' => 'Asst. Lect', 'specialization' => 'Computer and Information Systems Manager'),
				array('title' => 'Mal.','first_name' => 'Abdullahi', 'last_name' => 'Muhammad Nuhu', 'initial' => 'Bsc. Comp Sci (2016)', 'rank' => 'Asst. Lect', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Khalil', 'last_name' => 'Sani Ibrahim', 'initial' => 'Bsc. Comp Sci. (2017)', 'rank' => 'Asst. Lect', 'specialization' => 'Word Processing'),
				array('title' => 'Mrs.','first_name' => 'Aishatu', 'last_name' => 'Yahaya', 'initial' => 'Bsc. Comp Sci. (2016)', 'rank' => 'Asst. Lect', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Lawan', 'last_name' => 'Garba', 'initial' => 'B.Tech Comp Sci. (2017)', 'rank' => 'Asst. Lect', 'specialization' => 'Word Processing'),
				array('title' => 'Mal.','first_name' => 'Abubakar', 'last_name' => 'Ahmed Sambo', 'initial' => 'Bsc. Comp. Sci. (2014)', 'rank' => 'Asst. Lect', 'specialization' => 'Web Technology'),
				array('title' => 'Mrs.','first_name' => 'Aishatu', 'last_name' => 'Adam Yahaya', 'initial' => 'HND Comp Sci. (2018), PGD (2019)', 'rank' => 'Higher Instructor', 'specialization' => 'Word Processing'),
				array('title' => 'Mr.','first_name' => 'Ikenna', 'last_name' => 'Chukuwuka Onourah', 'initial' => 'HND Comp Sci.', 'rank' => 'Higher Instructor', 'specialization' => 'Programming, Applications Developer'),
				array('title' => 'Mal.','first_name' => 'Suleiman', 'last_name' => 'Abdulrasheed Sadiq', 'initial' => 'HND Comp Sci. (2012)', 'rank' => 'Technologist II', 'specialization' => 'Hardware Engineers'),
				array('title' => 'Mal.','first_name' => 'Abubakar', 'last_name' => 'Ahmad Yusuf', 'initial' => 'HND Comp Sci. (2015), PGD (2020)', 'rank' => 'Technologist II', 'specialization' => 'Programming, Web Technology, Database Administrator')
				);

	$_add_lecturer_stmt = mysqli_prepare($_connection,"INSERT INTO `lecturer` (`id`, `title`, `first_name`, `last_name`, `initial`, `rank`, `specialization`) VALUES(?,?,?,?,?,?,?)");
							mysqli_stmt_bind_param($_add_lecturer_stmt, 'issssss', $id,$title,$first_name,$last_name,$initial,$rank,$spec);
		for($l = 0; $l< count($lecturers); $l++){
			$id = time() + rand(1000,9999);
			$title = $lecturers[$l]['title'];
			$first_name = $lecturers[$l]['first_name'];
			$last_name = $lecturers[$l]['last_name'];
			$initial = $lecturers[$l]['initial'];
			$rank = $lecturers[$l]['rank'];
			$spec = $lecturers[$l]['specialization'];
		mysqli_stmt_execute($_add_lecturer_stmt);
		}
	}

	if(mysqli_num_rows(mysqli_query($_connection,"SELECT course_code FROM courses")) == 0){//if no course exist yet	
//Add all courses initially
$courses = array(
		array('code' => 'COM 101','title' => 'INTRODUCTION TO COMPUTERS','unit' => '3','level' => 'NDI','scope' => 'Computer and Information Systems Manager','lecturer' => ''),
		array('code' => 'COM 112','title' => 'INTRODUCTION TO DIGITAL ELECTRONICS','unit' => '3','level' => 'NDI','scope' => 'Digital Electronic','lecturer' => ''),
		array('code' => 'COM 113','title' => 'INTRODUCTION TO PROGRAMMING','unit' => '3','level' => 'NDI','scope' => 'Programming','lecturer' => ''),
		array('code' => 'GNS 103','title' => 'USE OF LIBRARY','unit' => '2','level' => 'NDI','scope' => 'Use of Library','lecturer' => ''),
	
		array('code' => 'GNS 127','title' => 'CITIZENSHIP EDUCATION I','unit' => '2','level' => 'NDI','scope' => 'Citizenshi Education','lecturer' => ''),
		array('code' => 'MTH 113','title' => 'LOGIC & LINEAR ALGEBRA','unit' => '2','level' => 'NDI','scope' => 'Logic and Linear Algebra', 'lecturer' => ''),
		array('code' => 'MTH 112','title' => 'FUNCTION AND GEOMETRY','unit' => '2','level' => 'NDI','scope' => 'Sample Survey, Statistical Inference','lecturer' => ''),
		array('code' => 'OTM 101','title' => 'TECHNICAL ENGLISH I','unit' => '2','level' => 'NDI','scope' => 'Function and Geometry','lecturer' => ''),
		array('code' => 'STA 112','title' => 'ELEMENTARY PROB. THEORY','unit' => '3','level' => 'NDI','scope' => 'Probability Theory','lecturer' => ''),
		array('code' => 'STA 114','title' => 'DESCRIPTIVE STATISTICS I','unit' => '3','level' => 'NDI','scope' => 'Descriptive Statistics','lecturer' => ''),
		//NDI SECOND SEMESTER COURSES
		array('code' => 'COM 121','title' => 'SCIENTIFIC PROGRAMMING LANGUAGE USING OO JAVA','unit' => '4','level' => 'NDI','scope' => 'Programming, Software Developer','lecturer' => ''),
		array('code' => 'COM 122','title' => 'INTRODUCTION TO INTERNET','unit' => '3','level' => 'NDI','scope' => 'Computer Network Architect','lecturer' => ''),
		array('code' => 'COM 123','title' => 'COMPUTER APPLICATION PACKAGES I','unit' => '4','level' => 'NDI','scope' => 'Word Processing','lecturer' => ''),
		array('code' => 'COM 124','title' => 'DATA STRUCTURE AND ALGORITHM','unit' => '3','level' => 'NDI','scope' => 'Data Structure, Data Architect','lecturer' => ''),
		array('code' => 'COM 125','title' => 'INTRODUCTION TO SYSTEM ANALYSIS','unit' => '3','level' => 'NDI','scope' => 'Systems Analyst, Computer and Information Research Scientists','lecturer' => ''),
		array('code' => 'COM 126','title' => 'PC UPGRADE AND MAINTENANCE','unit' => '4','level' => 'NDI','scope' => 'Computer Engineering, Hardware Engineers','lecturer' => ''),
		array('code' => 'EED 126','title' => 'INTRODUCTION TO ENTREPRENEURSHIP','unit' => '2','level' => 'NDI','scope' => 'Business Intelligence Analyst, Business Management','lecturer' => ''),
		array('code' => 'GNS 128','title' => 'CITIZENSHIP EDUCATION II','unit' => '2','level' => 'NDI','scope' => 'Citizinship Education','lecturer' => ''),
		//NDII COURSES
		array('code' => 'COM 211','title' => 'COMPUTER PROGRAMMING USING OO BASIC','unit' => '3','level' => 'NDII','scope' => 'Programming, Software Developer','lecturer' => ''),
		array('code' => 'COM 212','title' => 'INTRODUCTION TO SYSTEM PROGRAMMING','unit' => '3','level' => 'NDII','scope' => 'Programming','lecturer' => ''),
		array('code' => 'COM 213','title' => 'COMMERCIAL PROGRAMMING USING OO COBOL','unit' => '3','level' => 'NDII','scope' => 'Programming','lecturer' => ''),
		array('code' => 'COM 214','title' => 'FILE ORGANIZATION AND MANAGEMENT','unit' => '3','level' => 'NDII','scope' => 'IT Project Manager, Project Manager','lecturer' => ''),
		array('code' => 'COM 215','title' => 'COMPUTER PACKAGES II','unit' => '4','level' => 'NDII','scope' => 'Word Processing','lecturer' => ''),
		array('code' => 'COM 216','title' => 'COMPUTER SYSTEM TROUBLESHOOTING I','unit' => '3','level' => 'NDII','scope' => 'Hardware Engineers, Computer Engineering','lecturer' => ''),
		array('code' => 'EED 216','title' => 'PRACTICE OF ENTREPRENEURSHIP','unit' => '2','level' => 'NDII','scope' => 'Business Management','lecturer' => ''),
		array('code' => 'OTM 217','title' => 'TECHNICAL ENGLISH II','unit' => '2','level' => 'NDII','scope' => 'Technical English','lecturer' => ''),
		array('code' => 'SWE 200','title' => 'SIWES','unit' => '4','level' => 'NDII','scope' => 'Students Industrial Work Experience','lecturer' => ''),
		//NDII SECOND SEMESTER
		array('code' => 'COM 221','title' => 'COMPUTER PROGRAMMING USING OO FORTRAN','unit' => '4','level' => 'NDII','scope' => 'Programming','lecturer' => ''),
		array('code' => 'COM 222','title' => 'SEMINAR ON COMPUTER AND SOCIETY','unit' => '2','level' => 'NDII','scope' => 'IT Project Manager','lecturer' => ''),
		array('code' => 'COM 223','title' => 'BASIC HARDWARE MAINTAINANCE','unit' => '3','level' => 'NDII','scope' => 'Computer Engineering, Hardware Engineers','lecturer' => ''),
		array('code' => 'COM 224','title' => 'MANAGEMENT INFORMATION SYSTEM','unit' => '3','level' => 'NDII','scope' => 'Information Security Analyst','lecturer' => ''),
		array('code' => 'COM 225','title' => 'WEB TECHNOLOGY','unit' => '4','level' => 'NDII','scope' => 'Web Technology','lecturer' => ''),
		array('code' => 'COM 226','title' => 'COMPUTER SYSTEM TROUBLESHOOTING II','unit' => '3','level' => 'NDII','scope' => 'Computer Engineering','lecturer' => ''),
		array('code' => 'COM 229','title' => 'PROJECT','unit' => '3','level' => 'NDII','scope' => 'Project Research','lecturer' => ''),
		array('code' => 'STA 226','title' => 'SMALL BUSINESS MANAGEMENT I','unit' => '2','level' => 'NDII','scope' => 'Small Business Management','lecturer' => ''),
		
		//HND I COURSES
		array('code' => 'COM 311','title' => 'OPERATING SYSTEM I','unit' => '3','level' => 'HNDI','scope' => 'Software Engineering','lecturer' => ''),
		array('code' => 'COM 312','title' => 'DATABASE DESIGN I','unit' => '3','level' => 'HNDI','scope' => 'Database Administrator, Database Developer','lecturer' => ''),
		array('code' => 'COM 313','title' => 'COMPUTER PROGRAMMING USING C++','unit' => '3','level' => 'HNDI','scope' => 'Programming','lecturer' => ''),
		array('code' => 'COM 314','title' => 'COMPUTER ARCHITECTURE','unit' => '2','level' => 'HNDI','scope' => 'Data Architect','lecturer' => ''),
		array('code' => 'OTM 315','title' => 'BUSINESS COMMUNICATION I','unit' => '2','level' => 'HNDI','scope' => 'Business Communication','lecturer' => ''),
		array('code' => 'STA 314','title' => 'OPERATIONAL RESEARCH I','unit' => '3','level' => 'HNDI','scope' => '','lecturer' => ''),
		array('code' => 'STA3 11','title' => 'STATISTICS THEORY I','unit' => '2','level' => 'HNDI','scope' => '','lecturer' => ''),
		array('code' => 'COM 321','title' => 'OPERATING SYSTEM II','unit' => '3','level' => 'HNDI','scope' => '','lecturer' => ''),
		array('code' => 'COM 322','title' => 'DATABASE DESIGN II','unit' => '3','level' => 'HNDI','scope' => 'Database Administrator','lecturer' => ''),
		array('code' => 'COM 323','title' => 'ASSEMBLY LANGAUGE','unit' => '3','level' => 'HNDI','scope' => 'Programming','lecturer' => ''),
		array('code' => 'COM 324','title' => 'INTRODUCTION TO SOFTWARE ENGINEERING','unit' => '3','level' => 'HNDI','scope' => 'Software Engineering','lecturer' => ''),
		array('code' => 'COM 326','title' => 'INTRODUCTION TO HUMAN - COMPUTER INTERFACE (HCI)','unit' => '2','level' => 'HNDI','scope' => 'Multimedia','lecturer' => ''),
		array('code' => 'EED 323','title' => 'ENTREPRENEURSHIP DEVELOPMENT I','unit' => '2','level' => 'HNDI','scope' => '','lecturer' => ''),
		array('code' => 'OTM 412','title' => 'BUSINESS COMMUNICATION II','unit' => '3','level' => 'HNDI','scope' => '','lecturer' => ''),
		array('code' => 'STA 321','title' => 'STATISTICAL THEORY II','unit' => '2','level' => 'HNDI','scope' => '','lecturer' => ''),
		
		//HNDII COURSES
		array('code' => 'COM 412','title' => 'COMPUTER PROGRAMMING USING OO PASCAL','unit' => '3','level' => 'HNDII','scope' => 'Programming','lecturer' => ''),
		array('code' => 'COM 413','title' => 'PROJECT MANAGEMENT','unit' => '3','level' => 'HNDII','scope' => 'IT Project Manager','lecturer' => ''),
		array('code' => 'COM 414','title' => 'COMPILER CONSTRUCTION','unit' => '3','level' => 'HNDII','scope' => 'Applications Developer','lecturer' => ''),
		array('code' => 'COM 415','title' => 'DATA COMMUNICATION AND NETWORKS','unit' => '3','level' => 'HNDII','scope' => 'Computer Network Architect','lecturer' => ''),
		array('code' => 'COM 416','title' => 'MULTIMEDIA','unit' => '3','level' => 'HNDII','scope' => 'Multimedia','lecturer' => ''),
		array('code' => 'EED 413','title' => 'ENTREPRENEURSHIP DEVELOPMENT II','unit' => '2','level' => 'HNDII','scope' => 'Enterpreneurship Development','lecturer' => ''),
		array('code' => 'STA 411','title' => 'OPERATION RESEARCH II','unit' => '3','level' => 'HNDII','scope' => 'Operational Research','lecturer' => ''),
		array('code' => 'COM 422','title' => 'COMPUTER GRAPHICS AND ANIMATION','unit' => '3','level' => 'HNDII','scope' => 'Multimedia','lecturer' => ''),
		array('code' => 'COM 423','title' => 'INTRODUCTION TO ARTIFICIAL INTELLIGENCE AND EXPERT SYSTEMS','unit' => '3','level' => 'HNDII','scope' => 'AI Technology','lecturer' => ''),
		array('code' => 'COM 424','title' => 'PROFESSIONAL PRACTICE IN IT','unit' => '3','level' => 'HNDII','scope' => 'Artificial Intelligence','lecturer' => ''),
		array('code' => 'COM 425','title' => 'SEMINAR ON CURRENT TOPICS IN COMPUTING','unit' => '2','level' => 'HNDII','scope' => 'Seminar Presentation','lecturer' => ''),
		array('code' => 'COM 426','title' => 'SMALL BUSINESS STARTUP','unit' => '2','level' => 'HNDII','scope' => 'Business Startup','lecturer' => ''),
		array('code' => 'COM 429','title' => 'PROJECT','unit' => '6','level' => 'HNDII','scope' => 'Project Research','lecturer' => '')
	);
		
	$_add_course_stmt = mysqli_prepare($_connection,"INSERT INTO `courses` (`course_code`, `course_title`, `course_unit`, `level`, `course_scope`, `lecturer_in_charge`) VALUES(?,?,?,?,?,?)");
					mysqli_stmt_bind_param($_add_course_stmt, 'ssisss', $code,$title,$unit,$level,$scope,$lecturer);
		
		for($c = 0; $c< count($courses); $c++){
			$code = $courses[$c]['code'];
			$title = $courses[$c]['title'];
			$unit = $courses[$c]['unit'];
			$level = $courses[$c]['level'];
			$scope = $courses[$c]['scope'];
			$lecturer = $courses[$c]['lecturer'];
		mysqli_stmt_execute($_add_course_stmt);
		}		
	}	
		
		}
		mysqli_close($_connection);
}
else{
	echo "<h2 class=\"text-center\">Something went wrong</h2>";
}
/*******************************************************************************************/
