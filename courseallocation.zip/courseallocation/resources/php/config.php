<?php
//CONFIGURATIONS
//Make sure you read and understand the guide in READ ME.txt to complete this configuration
class config{
	static $db_host = "localhost";
	static $db_user = "root";
	static $db_password = "";
	static $department = "Computer";
}