<?php
session_start();
if(!isset($_SESSION['user_session'])){
	header("Location: login.php");
}
include_once("db_connect.php");
$sql = "SELECT uid, user, pass, email FROM users WHERE uid='".$_SESSION['user_session']."'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$row = mysqli_fetch_assoc($resultset);

?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Asqure Techz Solutions">
	<meta name="author" content="Abubakar Ahmad Yusuf">
	<link rel="icon" type="image/jpg" sizes="100x100" href="images/fav.jpg">
	<!--CSS resources-->
	<script type="text/javascript" language="javascript" src="resources/mato/tools/JQuery/jquery.min.js"></script>
	<link href="resources/mato/tools/bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
	<link href="resources/css/animate.css" type="text/css" rel="stylesheet" />
	<link href="resources/css/styles.css" type="text/css" rel="stylesheet" />
	<script  type="text/javascript" language="javascript" src="resources/mato/lib/JMatt/global.js"></script>
	<script  type="text/javascript" language="javascript" src="resources/mato/lib/JMatt/modal.js"></script>

		<!--<script type="text/javascript" language="javascript" src="../shelter/resources/mato/tools/JQuery/jquery.min.js"></script>
			<script type="text/javascript" language="javascript" src="../shelter/resources/mato/tools/bootstrap/js/bootstrap.min.js"></script>-->
			<!--Scripts from JMatt Library-->
		<!--<script  type="text/javascript" language="javascript" src="../shelter/resources/mato/lib/JMatt/global.js"></script>
			<script  type="text/javascript" language="javascript" src="../shelter/resources/mato/lib/JMatt/modal.js"></script>-->

			<title>Course Allocation System</title>
		</head>
		<body>
			<div class="row" id="header">
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
					<img src="resources/img/polylogo.jpg" width="85px" height="auto"/>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
					<h1>Course Allocation System</h1>
					<h4><?php require('resources/php/config.php');
					echo (config::$department == "" ? "Unnamed Department" : config::$department.' Department')?></h4>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 text-center" style="padding-top:30px">
					<span class="glyphicon glyphicon-repeat" style="color:white;font-size:30px;cursor:pointer" title="refresh" onclick="refresh()"></span> &nbsp; &nbsp;
					<a href="logout.php"><span class="glyphicon glyphicon-log-out" style="color:white;font-size:30px;cursor:pointer" title="logout"></span></a>
				</div>
			</div>
			<div class="container-fluid">
				<br>
				<div class="row">
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12" id="side-menu">
						<p>Welcome <?php echo $row['user']; ?></p>
						<ul style="line-height:30px" class="list-group">
							<h2>Courses</h2>
							<button class="btn btn-default" id="add-new-course">
								<span class="glyphicon glyphicon-plus-sign"></span>  Add new course
							</button>
							<li class="list-group-item" id="all-courses">All Courses </li>
							<li class="list-group-item" id="NDI-courses">NDI Courses</li>
							<li class="list-group-item" id="NDII-courses">NDII Courses</li>
							<li class="list-group-item" id="HNDI-courses">HNDI Courses</li>
							<li class="list-group-item" id="HNDII-courses">HNDII Courses</li>
							<h2>Lecturers</h2>
							<button class="btn btn-default" id="add-new-lecturer">
								<span class="glyphicon glyphicon-plus-sign"></span>  Add new lecturer
							</button>
							<li class="list-group-item"  id="all-lecturers">All Lectures</li>
						</ul>
					</div>
					<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" id="main">
						<div id="main-inner">

						</div>
					</div>
				</div>
			</div>
		</body>
		<script  type="text/javascript" language="javascript" src="resources/js/js.js"></script>
		<script  type="text/javascript" language="javascript" src="resources/js/l.js"></script>
		<script  type="text/javascript" language="javascript" src="resources/js/c.js"></script>
		<script>
	//load all courses by default
	get_content('all-courses');
</script>
</html>